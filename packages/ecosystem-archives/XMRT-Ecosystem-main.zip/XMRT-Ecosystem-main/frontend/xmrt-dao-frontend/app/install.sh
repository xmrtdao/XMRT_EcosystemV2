#!/bin/bash
# Force npm installation
npm install -g npm@latest
npm install
