#!/bin/bash
# Force PNPM version installation
npm install -g pnpm@8
pnpm install --store=node_modules/.pnpm-store
