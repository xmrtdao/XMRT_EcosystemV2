export { Heading, type HeadingSize, type IHeadingProps } from './heading';
