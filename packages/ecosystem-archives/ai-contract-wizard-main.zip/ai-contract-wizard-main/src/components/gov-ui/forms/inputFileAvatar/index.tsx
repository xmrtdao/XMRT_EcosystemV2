export { InputFileAvatar } from './inputFileAvatar';
export { InputFileAvatarError, type IInputFileAvatarProps, type IInputFileAvatarValue } from './inputFileAvatar.api';
