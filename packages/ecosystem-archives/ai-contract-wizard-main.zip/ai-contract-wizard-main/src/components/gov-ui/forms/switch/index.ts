export { Switch, type ISwitchProps } from './switch';
