export { TextAreaRichText, type ITextAreaRichTextProps } from './textAreaRichText';
