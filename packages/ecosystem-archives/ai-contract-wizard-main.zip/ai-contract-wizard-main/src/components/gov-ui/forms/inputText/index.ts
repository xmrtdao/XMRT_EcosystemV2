export { InputText } from './inputText';
export type { IInputTextProps } from './inputText.api';
