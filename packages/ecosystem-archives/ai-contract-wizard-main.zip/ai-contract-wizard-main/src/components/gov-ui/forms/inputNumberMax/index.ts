export { InputNumberMax, type IInputNumberMaxProps } from './inputNumberMax';
