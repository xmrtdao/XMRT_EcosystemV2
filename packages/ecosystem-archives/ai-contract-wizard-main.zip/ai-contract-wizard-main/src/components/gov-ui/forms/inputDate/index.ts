export { InputDate, type IInputDateProps } from './inputDate';
