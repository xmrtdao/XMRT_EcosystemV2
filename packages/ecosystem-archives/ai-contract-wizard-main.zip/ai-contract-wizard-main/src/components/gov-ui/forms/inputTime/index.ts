export { InputTime, type IInputTimeProps } from './inputTime';
