export { InputSearch, type IInputSearchProps } from './inputSearch';
