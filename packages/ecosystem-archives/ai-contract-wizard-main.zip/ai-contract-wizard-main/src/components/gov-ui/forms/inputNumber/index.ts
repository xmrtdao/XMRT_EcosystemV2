export { InputNumber, type IInputNumberProps } from './inputNumber';
