export { TextArea, type ITextAreaProps } from './textArea';
