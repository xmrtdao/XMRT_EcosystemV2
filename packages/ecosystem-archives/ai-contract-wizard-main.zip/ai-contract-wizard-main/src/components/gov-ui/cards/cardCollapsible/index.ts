export { CardCollapsible, type ICardCollapsibleProps } from './cardCollapsible';
