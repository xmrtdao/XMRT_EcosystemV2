export { Card, type ICardProps } from './card';
