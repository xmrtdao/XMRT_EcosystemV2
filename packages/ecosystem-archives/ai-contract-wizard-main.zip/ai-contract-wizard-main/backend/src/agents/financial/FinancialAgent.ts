export class FinancialAgent { async analyzeBudgetAndCosts(contract: any) { return { overallScore: 92, risks: [] }; } async healthCheck() { return true; } }
