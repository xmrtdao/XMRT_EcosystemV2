# XPLA Wormhole Contract Deployment

This readme describes the steps for building, verifying, and deploying XPLA smart contracts for Wormhole.

**WARNING**: _This process is only Linux host compatible at this time._
