pub use cw_wormhole::contract;
#[cfg(test)]
mod testing;
