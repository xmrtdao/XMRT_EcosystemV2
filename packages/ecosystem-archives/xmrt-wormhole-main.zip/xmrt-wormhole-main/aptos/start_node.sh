#!/bin/bash

aptos node run-local-testnet --with-faucet --force-restart --bind-to 0.0.0.0
