# Changelog

## 0.0.3

### Changed

Build a minified bundle

## 0.0.2

### Changed

Make `worm` directory agnostic

## 0.0.1

Initial release
