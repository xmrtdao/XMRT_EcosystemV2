---
name: Guardian software bug report
about: Submit a bug ticket if you have an issue with the guardian software. If you're a user, check out the Wormhole Discord server below for faster assistance.
title: ''
labels: ['bug', 'guardian-support']
assignees: ''
---
<!--- Fill out all the fields below for faster assistance. -->

## Description
<!-- Please describe the issue in detail. Include logs, errors, and expected behavior. -->

## Recommendation
<!-- Not necessary, but feel free to recommend a way to fix the issue. -->