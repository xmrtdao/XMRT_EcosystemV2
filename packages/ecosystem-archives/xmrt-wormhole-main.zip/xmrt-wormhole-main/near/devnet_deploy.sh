#!/bin/bash -f

npx ts-node devnet_deploy.ts
