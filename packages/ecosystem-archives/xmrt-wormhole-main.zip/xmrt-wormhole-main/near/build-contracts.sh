#!/bin/bash

source $HOME/.cargo/env
make build

