declare module 'varint' {
	export function encode(n: number): Uint8Array
}
