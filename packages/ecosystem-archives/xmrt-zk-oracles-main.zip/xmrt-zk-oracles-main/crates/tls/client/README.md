# TLS Client

This crate is a derivative of [rustls](https://github.com/rustls/rustls) with
significant modifications to facilitate the TLSNotary protocol.

This crate is licensed under the same terms as rustls.