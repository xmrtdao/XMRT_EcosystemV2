# TLS Core Types

This crate is a derivative of [rustls](https://github.com/rustls/rustls).

This crate is licensed under the same terms as rustls.