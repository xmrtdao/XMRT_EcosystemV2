/// Latency between the server and the prover.
pub const SERVER_LATENCY: usize = 50;
